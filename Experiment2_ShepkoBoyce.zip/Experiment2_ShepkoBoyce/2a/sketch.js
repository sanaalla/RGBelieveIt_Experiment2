var colors;
var capture;
var trackingData;

function setup() {
  createCanvas(windowWidth,windowHeight);
  capture = createCapture(VIDEO); //capture the webcam
  capture.style('opacity',0)// hiding the capture
  capture.id("myVideo"); //give the capture an ID so we can use it in the tracker below.
  colors = new tracking.ColorTracker(['cyan']);//only capturing magenta
  tracking.track('#myVideo', colors); // start the tracking of the colors above on the camera in p5
  //start detecting the tracking
  colors.on('track', function(event) { //this happens each time the tracking happens
      trackingData = event.data // break the trackingjs data into a global so we can access it with p5
  });

}

function draw() {
  background(2, 7, 15);
fill(1, 110, 179);//change color here//
  // console.log(trackingData);
  if(trackingData){ //if there is tracking data to look at, then...
    for (var i = 0; i < trackingData.length; i++) { //loop through each of the detected colors
 
 //this creates the visualization//
  var ang1 = TWO_PI * noise(0.01*frameCount + 10);    
  var ang2 = TWO_PI * noise(0.01*frameCount + 20);
  var ang3 = TWO_PI * noise(0.01*frameCount + 30);
  var rx = 60 * noise(0.01*frameCount + 40);
  var tx = 200 * noise(0.01*frameCount + 50);
  var size1 = 200 * noise(0.01*frameCount + 60);
  var size2 = 50 * noise(0.01*frameCount + 60);

//this is where the tracking data affects the motion of the visualization//
  translate(trackingData[i].x*2.2,trackingData[i].y*2,trackingData[i].width,trackingData[i].height);
  for (var i = 0; i < 8; i++) {
    push();
    rotate(ang1 + TWO_PI * i / 8);
    translate(tx, 0);
    rect(0,0, size1, size1);
    for (var j = 0; j < 6; j++) {
      push();
      rotate(ang2 + TWO_PI * j / 6);
      translate(rx, 0);
      rotate(ang3);
      //this is where the spinning happens//
      rect(rx, 0, size2, size2);
      pop();


    }   
    translate()
    pop();
  
 // console.log( trackingData[i] )
  }
}
 


  
  }
}