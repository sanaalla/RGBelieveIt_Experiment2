var colors;
var capture;
var trackingData;

function setup() {
  createCanvas(windowWidth,windowHeight)

  capture = createCapture(VIDEO); //capture the webcam
  capture.position(0,0) //move the capture to the top left
  capture.style('opacity',0)// use this to hide the capture later on (change to 0 to hide)...
  capture.id("myVideo"); //give the capture an ID so we can use it in the tracker below.

  colors = new tracking.ColorTracker(['yellow']);
  tracking.track('#myVideo', colors, { camera: true });
// start the tracking of the colors above on the camera in p5

  //start detecting the tracking
  colors.on('track', function(event) { //this happens each time the tracking happens
      trackingData = event.data // break the trackingjs data into a global so we can access it with p5
  });

}

function draw() {
  background(2, 7, 15);
fill(255, 151, 15);

    // console.log(trackingData);
  if(trackingData){ //if there is tracking data to look at, then...
    for (var i = 0; i < trackingData.length; i++) { //loop through each of the detected colors

      // console.log( trackingData[i] )
      ellipse(trackingData[i].x*2.3,trackingData[i].y*1,trackingData[i].width,trackingData[i].height)


    
    
    }
  }
  function windowResized() 
{
  resizeCanvas(windowWidth, windowHeight);
}

}